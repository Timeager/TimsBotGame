import telebot 
import random
from telebot import types
bot = telebot.TeleBot("7943324889:AAE3Jv8CmUfuDjZXfjSOrRaW4EyM5iAEK4E")

game = ["Камень", "Ножницы", "Бумага"]
@bot.message_handler(commands = ['start'])


def handle_start(message):

  keyboard = types.ReplyKeyboardMarkup(True)
  button1 = types.KeyboardButton("Камень")
  button2 = types.KeyboardButton("Ножницы")
  button3 = types.KeyboardButton("Бумага")
  keyboard.add(button1, button2, button3)
  
  bot.send_message(message.chat.id, "Привет, я бот queci, давай сыграем в камень, ножницы, бумага!", reply_markup=keyboard)


@bot.message_handler(func=lambda message: True)
def handle_message(message):

  random_object = random.choice(game)
  
  result = "Ничья! Я выбрал " + random_object

  if random_object == "Камень" and message.text == "Ножницы":
    result = "Ты проиграл! Я выбрал - Камень " 
  elif random_object == "Бумага" and message.text == "Ножницы":
    result = "Ты выиграл! Я выбрал - Бумагу " 
  elif random_object == "Ножницы" and message.text == "Ножницы":
    result = "Ничья! Я выбрал - Ножницы " 

  if random_object == "Ножницы" and message.text == "Бумага":
    result = "Ты проиграл! Я выбрал - Ножницы " 
  elif random_object == "Камень" and message.text == "Бумага":
    result = "Ты выиграл! Я выбрал - Камень " 
  elif random_object == "Бумага" and message.text == "Бумага":
    result = "Ничья! Я выбрал - Бумагу" 

  if random_object == "Бумага" and message.text == "Камень":
    result = "Ты проиграл! Я выбрал - Бумагу " 
  elif random_object == "Ножницы" and message.text == "Камень":
    result = "Ты выиграл! Я выбрал - Ножницы " 
  elif random_object == "Камень" and message.text == "Камень":
    result = "Ничья! Я выбрал - Камень "

  bot.reply_to(message, result)

  
bot.polling(none_stop=True)